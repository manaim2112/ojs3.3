<?php

/**
 * @file plugins/themes/modern/ModernThemePlugin.inc.php
 *
 * Copyright (c) 2014-2021 Simon Fraser University
 * Copyright (c) 2003-2021 John Willinsky
 * Distributed under the GNU GPL v3. For full terms see the file docs/COPYING.
 *
 * @class ModernThemePlugin
 * @ingroup plugins_themes_modern
 *
 * @brief Modern theme — fully colour-customisable.
 */

import('lib.pkp.classes.plugins.ThemePlugin');
import('classes.file.PublicFileManager');

class ModernThemePlugin extends ThemePlugin
{
	/**
	 * Built-in colour presets. Each preset defines the header colour and an
	 * accent colour used for buttons/links. Users can pick a preset OR enable
	 * a custom colour with the "custom" option below.
	 *
	 * @var array
	 */
	protected $colourPresets = [
		'ocean'    => ['label' => 'Ocean Blue (Default)', 'header' => '#1E6292', 'accent' => '#0EA5E9'],
		'midnight' => ['label' => 'Midnight Indigo',      'header' => '#1E1B4B', 'accent' => '#6366F1'],
		'royal'    => ['label' => 'Royal Purple',          'header' => '#581C87', 'accent' => '#A855F7'],
		'rose'     => ['label' => 'Rose Pink',             'header' => '#9F1239', 'accent' => '#F43F5E'],
		'crimson'  => ['label' => 'Crimson Red',           'header' => '#991B1B', 'accent' => '#EF4444'],
		'sunset'   => ['label' => 'Sunset Orange',         'header' => '#9A3412', 'accent' => '#F97316'],
		'amber'    => ['label' => 'Amber Gold',            'header' => '#92400E', 'accent' => '#F59E0B'],
		'gold'     => ['label' => 'Elegant Gold',          'header' => '#854D0E', 'accent' => '#D4AF37'],
		'forest'   => ['label' => 'Forest Green',          'header' => '#14532D', 'accent' => '#10B981'],
		'teal'     => ['label' => 'Tropical Teal',         'header' => '#115E59', 'accent' => '#14B8A6'],
		'slate'    => ['label' => 'Modern Slate',          'header' => '#1F2937', 'accent' => '#3B82F6'],
		'graphite' => ['label' => 'Graphite Dark',         'header' => '#111827', 'accent' => '#FBBF24'],
	];

	/**
	 * @copydoc ThemePlugin::isActive()
	 */
	public function isActive()
	{
		if (defined('SESSION_DISABLE_INIT')) {
			return true;
		}
		return parent::isActive();
	}

	/**
	 * Initialize theme: register options, build LESS variable overrides,
	 * register stylesheets/scripts and other hooks.
	 */
	public function init()
	{
		AppLocale::requireComponents(LOCALE_COMPONENT_PKP_MANAGER, LOCALE_COMPONENT_APP_MANAGER);

		$this->registerOptions();
		$this->registerAssets();
	}

	/**
	 * Theme settings panel options.
	 */
	protected function registerOptions()
	{
		// ---- Analytics ----
		$this->addOption('statCounter_project_id', 'FieldText', [
			'label' => 'StatCounter Project ID',
			'description' => 'Project ID dari StatCounter (mis. 13121706). Kosongkan untuk menonaktifkan.',
		]);
		$this->addOption('statCounter_security_id', 'FieldText', [
			'label' => 'StatCounter Security ID',
			'description' => 'Security ID dari StatCounter.',
		]);

		// ---- Typography ----
		$this->addOption('typography', 'FieldOptions', [
			'type' => 'radio',
			'label' => __('plugins.themes.modern.option.typography.label'),
			'description' => __('plugins.themes.modern.option.typography.description'),
			'options' => [
				['value' => 'notoSans',           'label' => __('plugins.themes.modern.option.typography.notoSans')],
				['value' => 'notoSerif',          'label' => __('plugins.themes.modern.option.typography.notoSerif')],
				['value' => 'notoSerif_notoSans', 'label' => __('plugins.themes.modern.option.typography.notoSerif_notoSans')],
				['value' => 'notoSans_notoSerif', 'label' => __('plugins.themes.modern.option.typography.notoSans_notoSerif')],
				['value' => 'lato',               'label' => __('plugins.themes.modern.option.typography.lato')],
				['value' => 'lora',               'label' => __('plugins.themes.modern.option.typography.lora')],
				['value' => 'lora_openSans',      'label' => __('plugins.themes.modern.option.typography.lora_openSans')],
			],
			'default' => 'notoSans',
		]);

		// ---- Colour preset ----
		$presetOptions = [];
		foreach ($this->colourPresets as $value => $preset) {
			$presetOptions[] = ['value' => $value, 'label' => $preset['label']];
		}
		$presetOptions[] = ['value' => 'custom', 'label' => 'Custom — pakai warna manual di bawah'];

		$this->addOption('colourPreset', 'FieldOptions', [
			'type'        => 'radio',
			'label'       => __('plugins.themes.modern.option.colour.label'),
			'description' => 'Pilih palet warna siap pakai, atau "Custom" untuk mengatur warna sendiri.',
			'options'     => $presetOptions,
			'default'     => 'ocean',
		]);

		$this->addOption('customHeaderColour', 'FieldColor', [
			'label'       => 'Custom — Header Colour',
			'description' => 'Hanya berlaku jika preset = Custom. Default: #1E6292.',
			'default'     => '#1E6292',
		]);

		$this->addOption('customAccentColour', 'FieldColor', [
			'label'       => 'Custom — Accent / Link Colour',
			'description' => 'Warna untuk link, tombol, dan elemen interaktif. Hanya berlaku jika preset = Custom.',
			'default'     => '#0EA5E9',
		]);

		// ---- Header style ----
		$this->addOption('headerStyle', 'FieldOptions', [
			'type'        => 'radio',
			'label'       => 'Header Style',
			'description' => 'Pilih tampilan latar belakang header.',
			'options'     => [
				['value' => 'solid',    'label' => 'Solid — warna penuh, classic'],
				['value' => 'gradient', 'label' => 'Gradient — gradasi diagonal modern'],
				['value' => 'glass',    'label' => 'Glass — translucent dengan blur (cocok dengan header image)'],
			],
			'default' => 'gradient',
		]);

		// ---- Border radius / card shape ----
		$this->addOption('borderRadius', 'FieldOptions', [
			'type'        => 'radio',
			'label'       => 'Sudut Komponen (Border Radius)',
			'description' => 'Mengubah seberapa rounded card, button, dan form.',
			'options'     => [
				['value' => 'sharp',   'label' => 'Sharp — sudut tegas (2px)'],
				['value' => 'rounded', 'label' => 'Rounded — sudut sedang (8px) default'],
				['value' => 'pill',    'label' => 'Pill — sudut sangat membulat (16px)'],
			],
			'default' => 'rounded',
		]);

		// ---- Card style ----
		$this->addOption('cardStyle', 'FieldOptions', [
			'type'        => 'radio',
			'label'       => 'Card Style',
			'description' => 'Tampilan kartu artikel dan announcement.',
			'options'     => [
				['value' => 'flat',     'label' => 'Flat — minimalis, tanpa shadow'],
				['value' => 'soft',     'label' => 'Soft — shadow lembut (default)'],
				['value' => 'elevated', 'label' => 'Elevated — shadow lebih kuat dan hover lift'],
			],
			'default' => 'soft',
		]);

		// ---- Layout toggles ----
		$this->addOption('showDescriptionInJournalIndex', 'FieldOptions', [
			'label'   => __('manager.setup.contextSummary'),
			'options' => [
				['value' => true, 'label' => __('plugins.themes.modern.option.showDescriptionInJournalIndex.option')],
			],
			'default' => false,
		]);

		$this->addOption('useHomepageImageAsHeader', 'FieldOptions', [
			'label'       => __('plugins.themes.modern.option.useHomepageImageAsHeader.label'),
			'description' => __('plugins.themes.modern.option.useHomepageImageAsHeader.description'),
			'options'     => [
				['value' => true, 'label' => __('plugins.themes.modern.option.useHomepageImageAsHeader.option')],
			],
			'default' => false,
		]);
	}

	/**
	 * Register stylesheets, scripts, fonts, and dynamic LESS variables.
	 */
	protected function registerAssets()
	{
		$request = Application::get()->getRequest();

		// 1) Primary stylesheet (compiled by OJS LESS engine).
		$this->addStyle('stylesheet', 'styles/index.less');

		// 2) Modern enhancements layered on top — kept in a separate file so we
		// don't fight with the original variables/index file.
		$this->addStyle('modern-enhancements', 'styles/enhancements.less');

		// 3) Font selection.
		$this->registerFont();

		// 4) Build LESS variable overrides from theme options and inject them.
		$lessVars = $this->buildLessVariables();
		if (!empty($lessVars)) {
			$this->modifyStyle('stylesheet', ['addLessVariables' => implode("\n", $lessVars)]);
			$this->modifyStyle('modern-enhancements', ['addLessVariables' => implode("\n", $lessVars)]);
		}

		// 5) Inline CSS for header background image (optional homepage image).
		$this->registerHomepageImageBackground($request);

		// 6) FontAwesome from PKP shared assets.
		$this->addStyle(
			'fontAwesome',
			$request->getBaseUrl() . '/lib/pkp/styles/fontawesome/fontawesome.css',
			['baseUrl' => '']
		);

		// 7) jQuery (and jQuery UI) — needed by Bootstrap dropdown.
		$min      = Config::getVar('general', 'enable_minified') ? '.min' : '';
		$jquery   = $request->getBaseUrl() . '/lib/pkp/lib/vendor/components/jquery/jquery' . $min . '.js';
		$jqueryUI = $request->getBaseUrl() . '/lib/pkp/lib/vendor/components/jqueryui/jquery-ui' . $min . '.js';
		$this->addScript('jQuery', $jquery, ['baseUrl' => '']);
		$this->addScript('jQueryUI', $jqueryUI, ['baseUrl' => '']);

		// 8) Bootstrap dropdowns + theme JS.
		$this->addScript('popper', 'js/lib/popper/popper.js');
		$this->addScript('bsUtil', 'js/lib/bootstrap/util.js');
		$this->addScript('bsDropdown', 'js/lib/bootstrap/dropdown.js');
		$this->addScript('default', 'js/main.js');

		// 9) Menu areas exposed to the navigation manager.
		$this->addMenuArea(['primary', 'user']);
	}

	/**
	 * Register the typography font file based on selected option.
	 */
	protected function registerFont()
	{
		$typography = $this->getOption('typography');

		switch ($typography) {
			case 'notoSerif':
				$this->addStyle('font', 'styles/fonts/notoSerif.less');
				break;
			case 'notoSerif_notoSans':
			case 'notoSans_notoSerif':
				$this->addStyle('font', 'styles/fonts/notoSans_notoSerif.less');
				break;
			case 'lato':
				$this->addStyle('font', 'styles/fonts/lato.less');
				break;
			case 'lora':
				$this->addStyle('font', 'styles/fonts/lora.less');
				break;
			case 'lora_openSans':
				$this->addStyle('font', 'styles/fonts/lora_openSans.less');
				break;
			case 'notoSans':
			default:
				$this->addStyle('font', 'styles/fonts/notoSans.less');
				break;
		}
	}

	/**
	 * Build a list of LESS variables based on theme options. These are injected
	 * BEFORE the theme stylesheet is compiled, overriding the defaults defined
	 * in styles/variables.less.
	 *
	 * @return array<string>
	 */
	protected function buildLessVariables()
	{
		$vars = [];

		// ---- Resolve colours ----
		[$header, $accent] = $this->resolveColours();

		// Always emit so the user-chosen colour wins over variables.less.
		$vars[] = '@bg-base: ' . $header . ';';
		$vars[] = '@primary: ' . $accent . ';';

		// Auto-adjust readable text colour based on header brightness.
		if (!$this->isColourDark($header)) {
			$vars[] = '@text-bg-base: rgba(0, 0, 0, 0.84);';
			$vars[] = '@bg-base-border-color: rgba(0, 0, 0, 0.18);';
		} else {
			$vars[] = '@text-bg-base: #ffffff;';
			$vars[] = '@bg-base-border-color: rgba(255, 255, 255, 0.14);';
		}

		// Expose secondary tokens for the enhancements stylesheet. We use
		// numeric flags rather than strings so LESS guards always evaluate
		// reliably across less.php versions.
		$headerStyle = $this->getOption('headerStyle') ?: 'gradient';
		$cardStyle   = $this->getOption('cardStyle')   ?: 'soft';

		$vars[] = '@modern-header-gradient: ' . ($headerStyle === 'gradient' ? '1' : '0') . ';';
		$vars[] = '@modern-header-glass: '    . ($headerStyle === 'glass'    ? '1' : '0') . ';';
		$vars[] = '@modern-card-flat: '       . ($cardStyle   === 'flat'     ? '1' : '0') . ';';
		$vars[] = '@modern-card-elevated: '   . ($cardStyle   === 'elevated' ? '1' : '0') . ';';

		// ---- Border radius ----
		$radiusMap = ['sharp' => '2px', 'rounded' => '8px', 'pill' => '16px'];
		$radius = $radiusMap[$this->getOption('borderRadius')] ?? '8px';
		$vars[] = '@border-radius: ' . $radius . ';';
		$vars[] = '@radius: '        . $radius . ';';

		return $vars;
	}

	/**
	 * Resolve the header + accent colour from preset / custom selection.
	 *
	 * @return array{0:string,1:string} [headerColour, accentColour]
	 */
	protected function resolveColours()
	{
		$preset = $this->getOption('colourPreset') ?: 'ocean';

		if ($preset === 'custom') {
			$header = $this->sanitizeHexColour($this->getOption('customHeaderColour') ?: '#1E6292');
			$accent = $this->sanitizeHexColour($this->getOption('customAccentColour') ?: '#0EA5E9');
		} elseif (isset($this->colourPresets[$preset])) {
			$header = $this->colourPresets[$preset]['header'];
			$accent = $this->colourPresets[$preset]['accent'];
		} else {
			// Fallback to default ocean
			$header = $this->colourPresets['ocean']['header'];
			$accent = $this->colourPresets['ocean']['accent'];
		}

		return [$header, $accent];
	}

	/**
	 * Validate a hex colour and fall back to a safe value when malformed.
	 * Prevents any user-supplied string from being injected into LESS verbatim.
	 *
	 * @param string $value
	 * @return string A 7-character #RRGGBB string.
	 */
	protected function sanitizeHexColour($value)
	{
		$value = trim((string) $value);
		if (preg_match('/^#([A-Fa-f0-9]{6})$/', $value)) {
			return $value;
		}
		if (preg_match('/^#([A-Fa-f0-9]{3})$/', $value, $m)) {
			$h = $m[1];
			return '#' . $h[0] . $h[0] . $h[1] . $h[1] . $h[2] . $h[2];
		}
		return '#1E6292';
	}

	/**
	 * Output an inline rule applying the current journal homepage image as a
	 * background for the header. Matches the original behaviour.
	 */
	protected function registerHomepageImageBackground($request)
	{
		if (!$this->getOption('useHomepageImageAsHeader')) {
			return;
		}
		$context = $request->getContext();
		if (!$context) {
			return;
		}
		$homepageImage = $context->getLocalizedData('homepageImage');
		if (!is_array($homepageImage) || empty($homepageImage['uploadName'])) {
			return;
		}

		$publicFileManager = new PublicFileManager();
		$publicFilesDir = $request->getBaseUrl() . '/' . $publicFileManager->getContextFilesPath($context->getId());
		$homepageImageUrl = $publicFilesDir . '/' . rawurlencode($homepageImage['uploadName']);

		$this->addStyle(
			'homepageImage',
			'.pkp_structure_head{background-image:linear-gradient(180deg,rgba(0,0,0,0.55),rgba(0,0,0,0.65)),url("' . $homepageImageUrl . '");background-size:cover;background-position:center;}',
			['inline' => true]
		);
	}

	/**
	 * @return string
	 */
	function getContextSpecificPluginSettingsFile()
	{
		return $this->getPluginPath() . '/settings.xml';
	}

	/**
	 * @return string
	 */
	function getInstallSitePluginSettingsFile()
	{
		return $this->getPluginPath() . '/settings.xml';
	}

	/**
	 * @return string
	 */
	function getDisplayName()
	{
		return __('plugins.themes.modern.name');
	}

	/**
	 * @return string
	 */
	function getDescription()
	{
		return __('plugins.themes.modern.description');
	}
}
